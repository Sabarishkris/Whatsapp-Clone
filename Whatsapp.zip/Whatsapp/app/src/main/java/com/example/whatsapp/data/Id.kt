package com.example.whatsapp.data

data class Id(
    val name: String,
    val value: String
)