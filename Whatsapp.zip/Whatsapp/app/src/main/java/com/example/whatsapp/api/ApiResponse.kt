package com.example.whatsapp.api



import com.example.whatsapp.data.Contacts
import retrofit2.Response
import retrofit2.http.GET

interface ApiResponse {
    @GET("/api/?results=50&inc=gender,name,picture,phone,cell,id,email")
    suspend fun getTopHeadlines(): Response<Contacts>
}