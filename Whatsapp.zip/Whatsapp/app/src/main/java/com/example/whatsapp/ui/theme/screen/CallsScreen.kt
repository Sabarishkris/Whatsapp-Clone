package com.example.whatsapp.ui.theme.screen

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.AddIcCall
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Update
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.whatsapp.util.ScreenUiEvents
import com.example.whatsapp.util.UiEvents
import com.example.whatsapp.viewmodel.ViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallsScreen(viewModel: ViewModel, navController: NavHostController) {
    var showMenu by remember { mutableStateOf(false) }
    val contacts = viewModel.contacts.value?.results ?: emptyList()


    val scaffold = remember {
        SnackbarHostState()
    }

    val uiEvents = viewModel.uiEvents.collectAsState(initial = null)

    uiEvents.value?.let { event ->
        LaunchedEffect(key1 = event) {
            Log.d("msgl", "enter")
            when (event) {
                is UiEvents.Navigate -> navController.navigate(event.route)
                is UiEvents.ShowSnackbar -> {
                    scaffold.showSnackbar(
                        message = event.message,
                    )
                }

                else -> Unit
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Calls",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ), actions = {
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = Icons.Outlined.QrCodeScanner,
                            contentDescription = ""
                        )

                    }
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = Icons.Outlined.CameraAlt,
                            contentDescription = ""
                        )

                    }
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = ""
                        )

                    }

                    IconButton(onClick = { showMenu = !showMenu }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = ""
                        )
                        DropdownMenu(expanded = showMenu, onDismissRequest = {
                            showMenu = false
                        }) {
                            DropdownMenuItem(
                                text = { Text(text = "Clear call log") },
                                onClick = {
                                })
                            DropdownMenuItem(
                                text = { Text(text = "Settings") },
                                onClick = { })
                        }

                    }
                })
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    BottomBarItem(
                        icon = Icons.AutoMirrored.Filled.Message,
                        label = "Chats",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.ChatClicked)})
                    BottomBarItem(
                        icon = Icons.Outlined.Update,
                        label = "Updates",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.UpdatesClicked)})
                    BottomBarItem(
                        icon = Icons.Outlined.Groups,
                        label = "Communities",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.CommunitiesClicked)})
                    BottomBarItem(
                        icon = Icons.Default.Call,
                        label = "Calls",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.CallsClicked)})
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center)
                    .padding(innerPadding)
            ) {
                Row (modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),){
                    Box(modifier = Modifier
                        .clip(CircleShape)
                        .size(40.dp)
                        .background(color = MaterialTheme.colorScheme.primary)){
                        Icon(Icons.Filled.Link, contentDescription ="link",
                            modifier = Modifier.fillMaxSize().padding(2.dp) )
                    }
                    Spacer(modifier = Modifier.width(15.dp))
                    Column(modifier = Modifier.wrapContentSize()
                        .align(Alignment.CenterVertically)) {
                        Text(
                            text = "Create call link",
                            fontSize = MaterialTheme.typography.titleMedium.fontSize,
                            fontWeight = FontWeight.Bold)
                        Text(
                            text = "Share a link for your Whatsapp call",
                            fontSize = MaterialTheme.typography.titleSmall.fontSize,
                            fontWeight = FontWeight.Normal)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
               Text(text = "Recent",
                   fontSize = MaterialTheme.typography.titleMedium.fontSize,
                   fontWeight = FontWeight.Bold,
                   modifier = Modifier.padding(10.dp)
               )
                Spacer(modifier = Modifier.height(10.dp))

                //Calls


            }

            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {

                FloatingActionButton(
                    onClick = {},
                    modifier = Modifier
                        .width(60.dp)
                        .height(60.dp)
                        .align(Alignment.CenterHorizontally),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    Icon(
                        Icons.Filled.AddIcCall,
                        contentDescription = "call",
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(30.dp)
                            .height(30.dp)
                    )
                }
            }
        }
    }

}