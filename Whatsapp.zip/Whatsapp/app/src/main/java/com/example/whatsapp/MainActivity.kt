package com.example.whatsapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.whatsapp.ui.theme.WhatsappTheme
import com.example.whatsapp.ui.theme.screen.CallsScreen
import com.example.whatsapp.ui.theme.screen.CommunitiesScreen
import com.example.whatsapp.ui.theme.screen.UpdatesScreen
import com.example.whatsapp.ui.theme.screen.WhatsappScreen
import com.example.whatsapp.util.Routes
import com.example.whatsapp.viewmodel.ViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val viewModel= ViewModel()
        setContent {
            WhatsappTheme {
                val navController = rememberNavController()

                if(viewModel.contactUiState is ViewModel.ContactUiState.Success) {
                    NavHost(navController = navController, startDestination = Routes.CHATS) {
                        composable(route = Routes.CHATS) {
                            WhatsappScreen(viewModel = viewModel,navController)
                        }
                        composable(route = Routes.UPDATES) {
                            UpdatesScreen(viewModel,navController)
                        }
                        composable(route = Routes.CALLS) {
                            CallsScreen(viewModel,navController)
                        }
                        composable(route = Routes.COMMUNITIES) {
                            CommunitiesScreen(viewModel,navController)
                        }

                    }
                }
                if (viewModel.contactUiState is ViewModel.ContactUiState.Loading) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}
