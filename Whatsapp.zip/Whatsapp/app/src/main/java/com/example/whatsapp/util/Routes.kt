package com.example.whatsapp.util

object Routes {
    const val CHATS="chats"
    const val UPDATES="updates"
    const val COMMUNITIES="communities"
    const val CALLS="calls"


}