package com.example.whatsapp.data

data class Contacts(
    val info: Info,
    val results: List<Result>
)